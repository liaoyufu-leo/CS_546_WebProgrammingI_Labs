const peopleData = require('./people');
const stocksData = require('./stocks');

module.exports = {
    people: peopleData,
    stocks: stocksData
};
